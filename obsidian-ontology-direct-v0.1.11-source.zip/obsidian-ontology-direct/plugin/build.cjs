const fs = require("node:fs");
const path = require("node:path");

const pluginDir = __dirname;
const mainPath = path.join(pluginDir, "main.js");
const source = fs.readFileSync(mainPath, "utf8").replace(/\r\n/g, "\n");

function inlineModule(targetText, sourceText, exportLine, importLine, variableNames) {
	if (!sourceText.includes(exportLine)) throw new Error(`Expected export line not found: ${exportLine}`);
	const body = sourceText.replace(exportLine, `return { ${variableNames} };`);
	return targetText.replace(importLine, `const { ${variableNames} } = (() => {\n${body}\n})();`);
}

function restoreImport(targetText, declaration, returnLine, importLine) {
	const start = targetText.indexOf(declaration);
	if (start < 0) return targetText;
	const endMarker = `${returnLine}\n})();`;
	const end = targetText.indexOf(endMarker, start);
	if (end < 0) throw new Error(`Bundled module end not found: ${declaration}`);
	return `${targetText.slice(0, start)}${importLine}${targetText.slice(end + endMarker.length)}`;
}

let bundled = source;
const mcpImport = 'const { StdioMcpClient } = require("./src/mcp-client");';
bundled = restoreImport(
	bundled,
	'const { StdioMcpClient } = (() => {',
	'return { StdioMcpClient };',
	mcpImport,
);
const mcpSource = fs.readFileSync(path.join(pluginDir, "src", "mcp-client.js"), "utf8").trim();
if (!bundled.includes(mcpImport)) throw new Error("MCP import line not found in main.js");
bundled = inlineModule(
	bundled,
	mcpSource,
	"module.exports = { StdioMcpClient };",
	mcpImport,
	"StdioMcpClient",
);

const llmImport = 'const { parseExtraction, postChatCompletion } = require("./src/llm-client");';
bundled = restoreImport(
	bundled,
	'const { postChatCompletion, parseExtraction } = (() => {',
	'return { postChatCompletion, parseExtraction };',
	llmImport,
);
const llmSource = fs.readFileSync(path.join(pluginDir, "src", "llm-client.js"), "utf8").trim();
if (!bundled.includes(llmImport)) throw new Error("LLM import line not found in main.js");
bundled = inlineModule(
	bundled,
	llmSource,
	"module.exports = { postChatCompletion, parseExtraction };",
	llmImport,
	"postChatCompletion, parseExtraction",
);

fs.writeFileSync(mainPath, bundled, "utf8");
console.log(`Bundled local modules into ${mainPath}`);
