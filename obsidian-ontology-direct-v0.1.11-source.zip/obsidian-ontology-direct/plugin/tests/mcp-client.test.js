const assert = require("node:assert/strict");
const { spawnSync } = require("node:child_process");
const { mkdtempSync, rmSync } = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const test = require("node:test");
const { StdioMcpClient } = require("../src/mcp-client");

const projectRoot = path.resolve(__dirname, "../..");
const serverPath = process.env.ONTOLOGY_SERVER || path.join(projectRoot, "server", "server.py");
const python = process.env.PYTHON || "python";

test("Python 3.11+ executable is available", () => {
	const result = spawnSync(python, ["--version"], { encoding: "utf8", windowsHide: true });
	assert.equal(result.status, 0, result.stderr || result.error?.message);
	assert.match(`${result.stdout}${result.stderr}`, /Python 3\.(1[1-9]|[2-9]\d)/);
});

test("Obsidian stdio client negotiates and runs ontology tools against an isolated DB", async () => {
	const temp = mkdtempSync(path.join(os.tmpdir(), "obsidian-ontology-test-"));
	const client = new StdioMcpClient({
		command: python,
		args: [serverPath],
		env: { ONTOLOGY_DB: path.join(temp, "ontology.sqlite"), PYTHONUTF8: "1" },
	});
	try {
		const initialized = await client.connect();
		assert.equal(initialized.serverInfo.name, "offline-ontology");
		const tools = await client.listTools();
		assert.ok(tools.some((tool) => tool.name === "ontology_ingest_document"));
		assert.ok(tools.some((tool) => tool.name === "ontology_query_graph"));

		const id = `codex-test-${Date.now()}`;
		const pathInVault = `__codex_test__/${id}.md`;
		const sha256 = require("node:crypto").createHash("sha256").update(pathInVault).digest("hex");
		const ingest = await client.callTool("ontology_ingest_document", {
			path: pathInVault,
			sha256,
			entities: [
				{ id: `system:${id}`, name: "Codex integration test", type: "System" },
				{ id: `technology:${id}`, name: "Local MCP test", type: "Technology" },
			],
			relations: [{
				subject: `system:${id}`,
				predicate: "USES",
				object: `technology:${id}`,
				evidence: "Synthetic integration-test evidence.",
				assertion: "explicit",
			}],
		});
		assert.equal(ingest.status, "indexed");
		const graph = await client.callTool("ontology_query_graph", { entity_id: `system:${id}`, depth: 1 });
		assert.equal(graph.relations.length, 1);
		assert.equal(graph.relations[0].evidence[0].quote, "Synthetic integration-test evidence.");
		const deleted = await client.callTool("ontology_delete_document", { path: pathInVault });
		assert.equal(deleted.deleted, true);
	} finally {
		await client.close();
		rmSync(temp, { recursive: true, force: true });
	}
});
