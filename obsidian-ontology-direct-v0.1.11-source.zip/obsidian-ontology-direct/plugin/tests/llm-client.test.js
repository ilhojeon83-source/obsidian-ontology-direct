const assert = require("node:assert/strict");
const test = require("node:test");
const { parseExtraction, postChatCompletion } = require("../src/llm-client");

test("Chat Completions client sends configured model and keeps auth in request headers", async () => {
	let captured;
	const content = await postChatCompletion({
		endpoint: "http://internal-llm.test/v1/chat/completions",
		apiKey: "test-secret",
		model: "qwen-test",
		messages: [{ role: "user", content: "ping" }],
		requestUrl: async (request) => {
			captured = request;
			return { status: 200, json: { choices: [{ message: { content: "pong" } }] } };
		},
	});
	assert.equal(content, "pong");
	assert.equal(captured.url, "http://internal-llm.test/v1/chat/completions");
	assert.equal(captured.headers.Authorization, "Bearer test-secret");
	assert.equal(JSON.parse(captured.body).model, "qwen-test");
	assert.equal(JSON.parse(captured.body).temperature, 0);
});

test("GPT-6 Luna uses Chat Completions reasoning_effort none without temperature", async () => {
	let captured;
	await postChatCompletion({
		endpoint: "https://api.openai.com/v1/chat/completions",
		apiKey: "test-secret",
		model: "gpt-6-luna",
		messages: [{ role: "user", content: "ping" }],
		requestUrl: async (request) => {
			captured = request;
			return { status: 200, json: { choices: [{ message: { content: "pong" } }] } };
		},
	});
	const body = JSON.parse(captured.body);
	assert.equal(body.reasoning_effort, "none");
	assert.equal("temperature" in body, false);
});

test("Chat Completions error includes the API's diagnostic message", async () => {
	await assert.rejects(
		postChatCompletion({
			endpoint: "https://api.openai.com/v1/chat/completions",
			apiKey: "test-secret",
			model: "gpt-6-luna",
			messages: [{ role: "user", content: "ping" }],
			requestUrl: async () => ({ status: 400, json: { error: { message: "unsupported parameter" } } }),
		}),
		/HTTP 400: unsupported parameter/,
	);
});

test("extractor accepts plain JSON and fenced JSON responses", () => {
	const json = JSON.stringify({ entities: [], relations: [] });
	assert.deepEqual(parseExtraction(json), { entities: [], relations: [] });
	assert.deepEqual(parseExtraction(`\`\`\`json\n${json}\n\`\`\``), { entities: [], relations: [] });
});

test("extractor rejects invalid shape", () => {
	assert.throws(() => parseExtraction('{"entities":[]}'), /entities\[\] and relations\[\]/);
});
