# Obsidian Ontology MCP Bridge

A desktop-only Obsidian plugin that calls the supplied local Python MCP server over stdio and can send a user-approved note to an OpenAI-compatible internal Chat Completions endpoint.

## What is included

- `plugin/`: installable Obsidian community-plugin source (`main.js` and `manifest.json`)
- `server/server.py`: the supplied offline ontology MCP server, unchanged
- `examples/vault/`: synthetic Markdown examples from the supplied archive
- `plugin/tests/`: Node built-in tests, including a real MCP stdio round trip against a temporary SQLite database

The plugin uses only Node built-ins and Obsidian's `requestUrl` API; no npm packages are required. `requestUrl` supports HTTP/HTTPS requests without browser CORS restrictions ([Obsidian API](https://docs.obsidian.md/Reference/TypeScript%20API/requestUrl)). MCP stdio starts the configured server process and exchanges JSON-RPC over stdin/stdout ([MCP transport documentation](https://py.sdk.modelcontextprotocol.io/client/transports/)).

## Install locally

1. Run `node plugin/build.cjs` from the project root. This embeds local JavaScript modules into the single `main.js` file Obsidian loads.
2. Copy `plugin/main.js` and `plugin/manifest.json` into `<your-vault>/.obsidian/plugins/obsidian-ontology-direct/`.
3. Keep `server/server.py` at a stable local path. In Obsidian, open **Settings → Community plugins** and enable **Ontology MCP Bridge**.
4. Open **Settings → Ontology MCP Bridge** and enter:
   - Python 3.11 executable path (or `python` if it resolves in Obsidian's environment)
   - absolute path to `server.py`
   - absolute path to a new or existing SQLite database file
   - your internal OpenAI-compatible Chat Completions URL and model
5. Enter the API key in the password field. The key stays in memory and is not saved to Obsidian's plugin data; re-enter it after Obsidian restarts. A blank key is accepted for endpoints that do not require one.
6. Run **Ontology MCP Bridge: Test local ontology MCP server** from the command palette to verify the Python process, SQLite DB, and available tools without using the LLM.
7. When the internal endpoint and model are configured, run **Ontology MCP Bridge: Run LLM + ontology MCP integration test**. It sends only a synthetic test sentence to the LLM, writes a uniquely named test document to the selected SQLite DB, checks the returned graph edge, and then deletes the test document.

The server creates a blank database and its tables automatically when it first starts. You only need the old SQLite DB if you want to keep previously accumulated ontology data.

## Analyze a note

Run **Ontology MCP Bridge: Review active note for ontology ingestion**. The plugin asks before sending the note text to the configured endpoint, then shows the extracted JSON for review. It writes nothing until you select **Save to ontology**. Only the current Markdown note is used.

The left ribbon has a **current note indexing** icon that opens this same review and save flow. It also has an **Ask the ontology** icon for querying indexed evidence and searching vault notes when the ontology has no matches.

## Query the ontology

Run **Ontology MCP Bridge: Ask the ontology and cite evidence**. The plugin searches SQLite through `ontology_search` and asks the configured LLM to synthesize indexed evidence. If the ontology has no matches, it searches Markdown notes in the active Obsidian vault, sends only the top matching excerpts to the LLM, and displays the summary with source paths and quotes. If neither source contains relevant text, it reports that instead of guessing.

## Python 3.11 UTF-8 setting

The MCP stdio protocol uses UTF-8. This plugin sets `PYTHONUTF8=1` for the child process because some Windows Python 3.11 installations otherwise use the system code page (for example CP949). No Python 3.13 installation is required for the included server.

## Run tests

From the project root:

```powershell
node --test plugin/tests/*.test.js
$env:PYTHONUTF8 = "1"
python -m unittest discover -s server/tests -v
```

The Node MCP integration test uses a temporary database under the system temp directory and removes it afterward. The LLM client test uses a stub response and does not contact any network service. The included Python suite contains the original 34 server tests.

## Important scope

This is a local desktop prototype. It does not provide vault-wide indexing, background watchers, or an HTTP server. It calls the Python MCP process on demand. The Chat Completions endpoint must accept a request of the form `{ model, messages, temperature }` and return `choices[0].message.content`. If the company's internal endpoint uses a different API shape, adapt `plugin/src/llm-client.js` before entering credentials.
