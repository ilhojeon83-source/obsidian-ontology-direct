function extractMessageContent(response) {
	const content = response?.choices?.[0]?.message?.content;
	if (typeof content === "string") return content;
	if (Array.isArray(content)) {
		return content.map((part) => (typeof part === "string" ? part : part?.text || "")).join("");
	}
	throw new Error("LLM response did not contain message content.");
}

async function postChatCompletion({ requestUrl, endpoint, apiKey, model, messages, temperature = 0 }) {
	if (!endpoint) throw new Error("OpenAI-compatible Chat Completions URL is not configured.");
	if (!model) throw new Error("LLM model is not configured.");
	if (typeof requestUrl !== "function") throw new Error("Obsidian requestUrl API is unavailable.");
	const headers = { "Content-Type": "application/json" };
	if (apiKey) headers.Authorization = `Bearer ${apiKey}`;
	const response = await requestUrl({
		url: endpoint,
		method: "POST",
		headers,
		body: JSON.stringify({ model, messages, temperature }),
		throw: false,
	});
	if (response.status < 200 || response.status >= 300) {
		throw new Error(`LLM request failed with HTTP ${response.status}. Check the endpoint, model, and authentication in plugin settings.`);
	}
	return extractMessageContent(response.json);
}

function parseExtraction(content) {
	const cleaned = content.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
	const result = JSON.parse(cleaned);
	if (!result || !Array.isArray(result.entities) || !Array.isArray(result.relations)) {
		throw new Error("LLM output must be JSON with entities[] and relations[].");
	}
	return result;
}

module.exports = { postChatCompletion, parseExtraction };
