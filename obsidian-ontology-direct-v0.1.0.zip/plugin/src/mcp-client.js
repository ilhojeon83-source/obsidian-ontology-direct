const { spawn } = require("child_process");

class StdioMcpClient {
	constructor({ command, args, env = {}, timeoutMs = 20000 }) {
		if (!command) throw new Error("Python executable is not configured.");
		if (!Array.isArray(args)) throw new Error("MCP server arguments must be an array.");
		this.command = command;
		this.args = args;
		this.env = env;
		this.timeoutMs = timeoutMs;
		this.process = null;
		this.nextId = 1;
		this.pending = new Map();
		this.buffer = "";
		this.stderrTail = "";
	}

	async connect() {
		if (this.process) throw new Error("MCP client is already connected.");
		this.process = spawn(this.command, this.args, {
			windowsHide: true,
			stdio: ["pipe", "pipe", "pipe"],
			env: { ...process.env, ...this.env, PYTHONUTF8: "1" },
		});
		this.process.stdout.setEncoding("utf8");
		this.process.stderr.setEncoding("utf8");
		this.process.stdout.on("data", (chunk) => this.#readStdout(chunk));
		this.process.stderr.on("data", (chunk) => {
			this.stderrTail = (this.stderrTail + chunk).slice(-4000);
		});
		this.process.on("error", (error) => this.#rejectAll(error));
		this.process.on("close", (code, signal) => {
			const detail = this.stderrTail.trim();
			this.#rejectAll(new Error(`MCP server exited (${signal || code}).${detail ? ` ${detail}` : ""}`));
			this.process = null;
		});

		const initialized = await this.request("initialize", {
			protocolVersion: "2025-06-18",
			capabilities: {},
			clientInfo: { name: "obsidian-ontology-direct", version: "0.1.0" },
		});
		this.notify("notifications/initialized");
		return initialized;
	}

	#readStdout(chunk) {
		this.buffer += chunk;
		let newline;
		while ((newline = this.buffer.indexOf("\n")) !== -1) {
			const line = this.buffer.slice(0, newline).trim();
			this.buffer = this.buffer.slice(newline + 1);
			if (!line) continue;
			let message;
			try {
				message = JSON.parse(line);
			} catch {
				this.#rejectAll(new Error("MCP server wrote non-JSON data to stdout."));
				continue;
			}
			const pending = this.pending.get(message.id);
			if (!pending) continue;
			this.pending.delete(message.id);
			clearTimeout(pending.timer);
			if (message.error) pending.reject(new Error(message.error.message || "MCP request failed."));
			else pending.resolve(message.result);
		}
	}

	request(method, params = {}) {
		if (!this.process || this.process.stdin.destroyed) {
			return Promise.reject(new Error("MCP server is not running."));
		}
		const id = this.nextId++;
		const payload = JSON.stringify({ jsonrpc: "2.0", id, method, params }) + "\n";
		return new Promise((resolve, reject) => {
			const timer = setTimeout(() => {
				this.pending.delete(id);
				reject(new Error(`MCP request timed out: ${method}`));
			}, this.timeoutMs);
			this.pending.set(id, { resolve, reject, timer });
			this.process.stdin.write(payload, "utf8", (error) => {
				if (!error) return;
				clearTimeout(timer);
				this.pending.delete(id);
				reject(error);
			});
		});
	}

	notify(method, params = {}) {
		if (!this.process || this.process.stdin.destroyed) return;
		this.process.stdin.write(JSON.stringify({ jsonrpc: "2.0", method, params }) + "\n", "utf8");
	}

	async listTools() {
		const result = await this.request("tools/list");
		return result.tools || [];
	}

	async callTool(name, arguments_) {
		const result = await this.request("tools/call", { name, arguments: arguments_ });
		if (result.isError) {
			const message = result.content?.map((item) => item.text || "").join("\n") || `${name} failed`;
			throw new Error(message);
		}
		const text = result.content?.find((item) => item.type === "text")?.text;
		if (text === undefined) return result;
		try {
			return JSON.parse(text);
		} catch {
			return text;
		}
	}

	#rejectAll(error) {
		for (const [id, pending] of this.pending) {
			clearTimeout(pending.timer);
			pending.reject(error);
			this.pending.delete(id);
		}
	}

	async close() {
		const child = this.process;
		if (!child) return;
		this.process = null;
		this.#rejectAll(new Error("MCP client closed."));
		await new Promise((resolve) => {
			const timer = setTimeout(() => {
				if (!child.killed) child.kill();
				resolve();
			}, 1500);
			child.once("close", () => {
				clearTimeout(timer);
				resolve();
			});
			child.stdin.end();
		});
	}
}

module.exports = { StdioMcpClient };
