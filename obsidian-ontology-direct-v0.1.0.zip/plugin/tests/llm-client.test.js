const assert = require("node:assert/strict");
const test = require("node:test");
const { parseExtraction, postChatCompletion } = require("../src/llm-client");

test("Chat Completions client sends configured model and keeps auth in request headers", async () => {
	let captured;
	const content = await postChatCompletion({
		endpoint: "http://internal-llm.test/v1/chat/completions",
		apiKey: "test-secret",
		model: "qwen-test",
		messages: [{ role: "user", content: "ping" }],
		requestUrl: async (request) => {
			captured = request;
			return { status: 200, json: { choices: [{ message: { content: "pong" } }] } };
		},
	});
	assert.equal(content, "pong");
	assert.equal(captured.url, "http://internal-llm.test/v1/chat/completions");
	assert.equal(captured.headers.Authorization, "Bearer test-secret");
	assert.equal(JSON.parse(captured.body).model, "qwen-test");
});

test("extractor accepts plain JSON and fenced JSON responses", () => {
	const json = JSON.stringify({ entities: [], relations: [] });
	assert.deepEqual(parseExtraction(json), { entities: [], relations: [] });
	assert.deepEqual(parseExtraction(`\`\`\`json\n${json}\n\`\`\``), { entities: [], relations: [] });
});

test("extractor rejects invalid shape", () => {
	assert.throws(() => parseExtraction('{"entities":[]}'), /entities\[\] and relations\[\]/);
});
