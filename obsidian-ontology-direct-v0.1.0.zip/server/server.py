#!/usr/bin/env python3
"""Dependency-free (Python standard library) MCP stdio ontology server."""
import hashlib
import json
import os
import re
import sqlite3
import sys
import uuid
import unicodedata
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parent
DB = Path(os.environ.get('ONTOLOGY_DB', str(BASE / 'data' / 'ontology.db'))).expanduser().resolve()
MAX_BYTES = 4 * 1024 * 1024
ENTITY_TYPES = ['Person','Organization','Project','System','Technology','Issue','Decision','Task','Idea','Document','Other']
PREDICATES = {
    'BELONGS_TO': None, 'AFFECTS': None, 'DEPENDS_ON': None,
    'ASSIGNED_TO': None, 'RESOLVED_BY': ('Issue','Task'),
    'DECIDED_IN': None, 'PROPOSES': None, 'USES': None,
    'RUNS_ON': None, 'RELATED_TO': None, 'CAUSED_BY': None,
    'IMPLEMENTS': None, 'BLOCKS': None, 'MENTIONS': None,
}
SCHEMA = '''
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS sources (
 path TEXT PRIMARY KEY, sha256 TEXT NOT NULL, indexed_at TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'indexed'
);
CREATE TABLE IF NOT EXISTS entities (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, type TEXT NOT NULL,
 properties TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS aliases (
 entity_id TEXT NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
 alias TEXT NOT NULL COLLATE NOCASE, PRIMARY KEY(entity_id, alias)
);
CREATE INDEX IF NOT EXISTS idx_entities_name ON entities(name COLLATE NOCASE);
CREATE INDEX IF NOT EXISTS idx_alias_name ON aliases(alias);
CREATE TABLE IF NOT EXISTS relations (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 subject_id TEXT NOT NULL REFERENCES entities(id),
 predicate TEXT NOT NULL, object_id TEXT NOT NULL REFERENCES entities(id),
 UNIQUE(subject_id, predicate, object_id)
);
CREATE INDEX IF NOT EXISTS idx_rel_subject ON relations(subject_id);
CREATE INDEX IF NOT EXISTS idx_rel_object ON relations(object_id);
CREATE TABLE IF NOT EXISTS evidence (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 source_path TEXT NOT NULL REFERENCES sources(path) ON DELETE CASCADE,
 relation_id INTEGER NOT NULL REFERENCES relations(id) ON DELETE CASCADE,
 quote TEXT NOT NULL, assertion TEXT NOT NULL DEFAULT 'explicit',
 UNIQUE(source_path, relation_id, quote)
);
CREATE INDEX IF NOT EXISTS idx_ev_relation ON evidence(relation_id);
'''

def now():
    return datetime.now(timezone.utc).isoformat()

@contextmanager
def dbconn():
    DB.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB), timeout=20)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys=ON')
    conn.execute('PRAGMA busy_timeout=20000')
    conn.execute('PRAGMA journal_mode=WAL')
    try:
        conn.executescript(SCHEMA)
        yield conn
        conn.commit()
    except BaseException:
        conn.rollback()
        raise
    finally:
        conn.close()

def fail(message):
    raise ValueError(message)

def string(v, name, limit=512):
    if not isinstance(v,str) or not v.strip() or len(v)>limit:
        fail(f'{name}: non-empty string (max {limit}) required')
    return v.strip()

def relative_path(value):
    p = string(value, 'path', 1024).replace('\\','/')
    if p.startswith('/') or re.match(r'^[A-Za-z]:', p) or any(x in ('','..','.') for x in p.split('/')):
        fail('path must be vault-relative without traversal')
    if not p.lower().endswith('.md'):
        fail('only .md paths accepted')
    return p

def schema_tool(args):
    return {'entity_types':ENTITY_TYPES, 'predicates':list(PREDICATES),
            'rules':'IDs are stable and case-sensitive; each relation needs source quote; inferred assertions flagged.'}

def document_state(args):
    paths = args.get('paths', [])
    if not isinstance(paths,list) or len(paths)>500: fail('paths must be array <=500')
    with dbconn() as c:
        if not paths:
            rows=c.execute('SELECT * FROM sources ORDER BY path LIMIT 500').fetchall()
        else:
            paths=[relative_path(p) for p in paths]
            rows=c.execute('SELECT * FROM sources WHERE path IN ('+','.join('?'*len(paths))+')',paths).fetchall()
    return {'documents':[dict(r) for r in rows]}

# Search uses standard-library Unicode normalization and deterministic ranking.
# Do not depend on optional SQLite FTS5 builds or any pip package.
TOKEN_RE = re.compile(r"[A-Za-z0-9]+|[가-힣]+|[\u3040-\u30ff]+|[\u4e00-\u9fff]+")
STOP_WORDS = frozenset(('the','a','an','and','or','of','for','to','in','on','with',
    '관련','대한','대해','관한','에서','에게','무엇','어떤','찾아줘','알려줘','검색','문서','내용'))

def normalize(value):
    value = unicodedata.normalize('NFKC', str(value)).casefold()
    return ' '.join(TOKEN_RE.findall(value))

def tokens(value):
    # Preserve meaningful numeric/version parts, ignore high-frequency query fillers.
    out=[]
    for token in TOKEN_RE.findall(unicodedata.normalize('NFKC', value).casefold()):
        if token not in STOP_WORDS and token not in out:
            out.append(token)
    return out[:20]

def search_parameters(args):
    query=string(args.get('query',''),'query',200)
    mode=args.get('mode','auto')
    if mode not in ('auto','all','any','phrase'): fail('mode must be auto/all/any/phrase')
    limit=max(1,min(int(args.get('limit',20)),100))
    terms=tokens(query)
    if not terms: terms=tokens(query.replace(' ', ''))
    if not terms: fail('query has no searchable terms')
    return query,terms,mode,limit

def rank_candidate(query, terms, fields):
    normalized_query=normalize(query)
    texts=[normalize(x) for x in fields if x]
    compact_query=normalized_query.replace(' ','')
    # Match across fields: title in one field, predicate or evidence in another.
    joined=' '.join(texts)
    compact_joined=joined.replace(' ','')
    matches=[t for t in terms if any(t in f.replace(' ','') for f in texts)]
    full=len(matches)==len(terms)
    exact=any(normalized_query==f for f in texts)
    phrase=any(normalized_query in f or compact_query in f.replace(' ','') for f in texts)
    prefix=any(f.startswith(normalized_query) for f in texts)
    # Full phrase outranks all-term matches; one-term fallbacks ranked by coverage.
    score=(1000 if exact else 0)+(350 if phrase else 0)+(90 if prefix else 0)
    score+=len(matches)*40 + (200 if full else 0)
    if matches: score+=max(0,60-len(joined)//20)
    return {'score':score,'matched_terms':matches,'all_terms_matched':full,'phrase_matched':phrase}

def filter_rank(query,terms,mode,candidates,limit):
    results=[]
    for item,fields in candidates:
        rank=rank_candidate(query,terms,fields)
        if not rank['matched_terms']: continue
        if mode=='phrase' and not rank['phrase_matched']: continue
        if mode=='all' and not rank['all_terms_matched']: continue
        results.append((rank['score'],item,rank))
    fallback=False
    if mode=='auto':
        complete=[x for x in results if x[2]['all_terms_matched']]
        if complete: results=complete
        else: fallback=True
    results.sort(key=lambda x:(-x[0], str(x[1].get('name',x[1].get('source_path',x[1].get('id','')))).casefold()))
    return [(item|rank) for _,item,rank in results[:limit]],fallback

def search_entities(args):
    query,terms,mode,limit=search_parameters(args)
    candidates=[]
    with dbconn() as c:
        rows=c.execute('SELECT * FROM entities ORDER BY id').fetchall()
        for row in rows:
            aliases=[a['alias'] for a in c.execute('SELECT alias FROM aliases WHERE entity_id=?',(row['id'],))]
            props=json.loads(row['properties'])
            item=dict(row)|{'properties':props,'aliases':aliases}
            candidates.append((item,[row['id'],row['name'],row['type'],*aliases,
                *[str(v) for v in props.values() if isinstance(v,(str,int,float))]]))
    results,fallback=filter_rank(query,terms,mode,candidates,limit)
    return {'entities':results,'query':query,'terms':terms,'mode':mode,'fallback_to_any':fallback,'total_candidates':len(candidates)}

def validate_doc(args):
    path=relative_path(args.get('path'))
    digest=string(args.get('sha256'),'sha256',64).lower()
    if not re.fullmatch('[0-9a-f]{64}',digest): fail('invalid sha256')
    entities=args.get('entities',[])
    relations=args.get('relations',[])
    if not isinstance(entities,list) or len(entities)>300: fail('entities array <=300')
    if not isinstance(relations,list) or len(relations)>500: fail('relations array <=500')
    clean_entities=[]; clean_relations=[]; ids=set()
    for e in entities:
        if not isinstance(e,dict): fail('entity must be object')
        eid=string(e.get('id'),'entity.id',160)
        name=string(e.get('name'),'entity.name',300)
        typ=string(e.get('type'),'entity.type',60)
        if typ not in ENTITY_TYPES: fail(f'unsupported entity type {typ}')
        props=e.get('properties',{})
        if not isinstance(props,dict) or len(json.dumps(props,ensure_ascii=False))>5000: fail('invalid properties')
        als=e.get('aliases',[])
        if not isinstance(als,list) or len(als)>30: fail('invalid aliases')
        als=[string(a,'alias',300) for a in als]
        if eid in ids: fail(f'duplicate id {eid}')
        ids.add(eid); clean_entities.append((eid,name,typ,props,als))
    for r in relations:
        if not isinstance(r,dict): fail('relation must be object')
        s=string(r.get('subject'),'relation.subject',160)
        p=string(r.get('predicate'),'relation.predicate',60)
        o=string(r.get('object'),'relation.object',160)
        quote=string(r.get('evidence'),'relation.evidence',2000)
        a=r.get('assertion','explicit')
        if p not in PREDICATES: fail(f'unsupported predicate {p}')
        if a not in ('explicit','inferred'): fail('assertion must be explicit or inferred')
        if s==o: fail('self-relations are not allowed')
        clean_relations.append((s,p,o,quote,a))
    return path,digest,clean_entities,clean_relations

def ingest(args):
    path,digest,entities,relations=validate_doc(args)
    force=bool(args.get('force',False))
    with dbconn() as c:
        c.execute('BEGIN IMMEDIATE')
        old=c.execute('SELECT sha256 FROM sources WHERE path=?',(path,)).fetchone()
        if old and old['sha256']==digest and not force:
            return {'status':'unchanged','path':path}
        # Validate every referenced ID before changing prior assertions.
        provided={x[0]:x for x in entities}
        known=set(provided)
        for x in c.execute('SELECT id FROM entities'): known.add(x['id'])
        for s,p,o,quote,a in relations:
            if s not in known or o not in known: fail(f'missing entity referenced by {s} -> {o}')
            rule=PREDICATES[p]
            if rule:
                st=provided[s][2] if s in provided else c.execute('SELECT type FROM entities WHERE id=?',(s,)).fetchone()['type']
                ot=provided[o][2] if o in provided else c.execute('SELECT type FROM entities WHERE id=?',(o,)).fetchone()['type']
                if p=='RESOLVED_BY' and (st!='Issue' or ot not in ('Task','Decision')):
                    fail('RESOLVED_BY expects Issue -> Task or Decision')
        c.execute('INSERT INTO sources(path,sha256,indexed_at) VALUES(?,?,?) ON CONFLICT(path) DO UPDATE SET sha256=excluded.sha256,indexed_at=excluded.indexed_at,status=\'indexed\'',(path,digest,now()))
        c.execute('DELETE FROM evidence WHERE source_path=?',(path,))
        for eid,name,typ,props,als in entities:
            existing=c.execute('SELECT type FROM entities WHERE id=?',(eid,)).fetchone()
            if existing and existing['type']!=typ: fail(f'type conflict: {eid}')
            c.execute('INSERT INTO entities(id,name,type,properties,created_at) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name, properties=excluded.properties',(eid,name,typ,json.dumps(props,ensure_ascii=False),now()))
            for alias in als:
                c.execute('INSERT OR IGNORE INTO aliases(entity_id,alias) VALUES(?,?)',(eid,alias))
        for s,p,o,quote,a in relations:
            c.execute('INSERT OR IGNORE INTO relations(subject_id,predicate,object_id) VALUES(?,?,?)',(s,p,o))
            rid=c.execute('SELECT id FROM relations WHERE subject_id=? AND predicate=? AND object_id=?',(s,p,o)).fetchone()['id']
            c.execute('INSERT OR IGNORE INTO evidence(source_path,relation_id,quote,assertion) VALUES(?,?,?,?)',(path,rid,quote,a))
        removed=prune(c)
    return {'status':'indexed','path':path,'entities_submitted':len(entities),'relations_submitted':len(relations),'orphan_relations_removed':removed}

def prune(c):
    cur=c.execute('DELETE FROM relations WHERE NOT EXISTS (SELECT 1 FROM evidence WHERE evidence.relation_id=relations.id)')
    return cur.rowcount

def delete_document(args):
    path=relative_path(args.get('path'))
    with dbconn() as c:
        c.execute('BEGIN IMMEDIATE')
        cur=c.execute('DELETE FROM sources WHERE path=?',(path,))
        removed=prune(c)
    return {'deleted':bool(cur.rowcount),'path':path,'orphan_relations_removed':removed,
            'note':'Entities are intentionally preserved; review unused entities manually.'}

def graph(args):
    root=string(args.get('entity_id'),'entity_id',160)
    depth=int(args.get('depth',2)); depth=max(0,min(depth,5))
    limit=max(1,min(int(args.get('limit',100)),300))
    with dbconn() as c:
        if not c.execute('SELECT 1 FROM entities WHERE id=?',(root,)).fetchone(): fail('unknown entity_id')
        reached={root}; frontier={root}; edges={}
        for _ in range(depth):
            if not frontier or len(edges)>=limit: break
            next_nodes=set()
            for node in sorted(frontier):
                rows=c.execute('''SELECT * FROM relations WHERE subject_id=? OR object_id=? ORDER BY id LIMIT ?''',(node,node,limit)).fetchall()
                for r in rows:
                    edges[r['id']]=dict(r)
                    next_nodes.update([r['subject_id'],r['object_id']])
                    if len(edges)>=limit: break
                if len(edges)>=limit: break
            frontier=next_nodes-reached; reached.update(next_nodes)
        ent=[]
        for eid in sorted(reached):
            r=c.execute('SELECT id,name,type FROM entities WHERE id=?',(eid,)).fetchone()
            if r: ent.append(dict(r))
        rel=[]
        for rid,r in sorted(edges.items()):
            ev=c.execute('SELECT source_path,quote,assertion FROM evidence WHERE relation_id=? ORDER BY source_path LIMIT 10',(rid,)).fetchall()
            rel.append(r|{'evidence':[dict(x) for x in ev]})
    return {'entities':ent,'relations':rel,'truncated':len(edges)>=limit}

def search(args):
    query,terms,mode,limit=search_parameters(args)
    candidates=[]
    with dbconn() as c:
        rows=c.execute("""SELECT ev.source_path,ev.quote,ev.assertion,
          r.subject_id,r.predicate,r.object_id,
          s.name AS subject_name,o.name AS object_name,
          s.type AS subject_type,o.type AS object_type
          FROM evidence ev JOIN relations r ON r.id=ev.relation_id
          JOIN entities s ON s.id=r.subject_id
          JOIN entities o ON o.id=r.object_id
          ORDER BY ev.id DESC""")
        alias_cache={}
        for row in rows:
            item=dict(row)
            fields=[item['source_path'],item['quote'],item['subject_id'],item['object_id'],
                    item['subject_name'],item['object_name'],item['predicate'],
                    item['subject_type'],item['object_type']]
            for entity_id in (item['subject_id'],item['object_id']):
                if entity_id not in alias_cache:
                    alias_cache[entity_id]=[a['alias'] for a in c.execute(
                        'SELECT alias FROM aliases WHERE entity_id=?',(entity_id,))]
                fields.extend(alias_cache[entity_id])
            candidates.append((item,fields))
    results,fallback=filter_rank(query,terms,mode,candidates,limit)
    return {'matches':results,'query':query,'terms':terms,'mode':mode,'fallback_to_any':fallback,'total_candidates':len(candidates)}

def stats(args):
    with dbconn() as c:
        return {t:c.execute(f'SELECT count(*) FROM {t}').fetchone()[0] for t in ('entities','relations','sources','evidence','aliases')}

TOOLS = {
 'ontology_get_schema':('Allowed types and predicates',schema_tool,{},[]),
 'ontology_get_document_state':('Get indexed paths and SHA256 checksums',document_state,{'paths':{'type':'array','items':{'type':'string'}}},[]),
 'ontology_search_entities':('Unicode-normalized entity search: split terms, rank exact/phrase/all, fallback to any; mode auto/all/any/phrase',search_entities,{'query':{'type':'string'},'limit':{'type':'integer'},'mode':{'type':'string','enum':['auto','all','any','phrase']}},['query']),
 'ontology_ingest_document':('Atomically replace document evidence and upsert extracted ontology',ingest,{'path':{'type':'string'},'sha256':{'type':'string'},'entities':{'type':'array','items':{'type':'object'}},'relations':{'type':'array','items':{'type':'object'}},'force':{'type':'boolean'}},['path','sha256','entities','relations']),
 'ontology_delete_document':('Delete document evidence without deleting shared entities',delete_document,{'path':{'type':'string'}},['path']),
 'ontology_query_graph':('Traverse undirected relationships from an entity',graph,{'entity_id':{'type':'string'},'depth':{'type':'integer'},'limit':{'type':'integer'}},['entity_id']),
 'ontology_search':('Search evidence, paths, entity names, IDs, types and aliases with token splitting and ranked fallback; mode auto/all/any/phrase',search,{'query':{'type':'string'},'limit':{'type':'integer'},'mode':{'type':'string','enum':['auto','all','any','phrase']}},['query']),
 'ontology_stats':('Get counts by table',stats,{},[]),
}

def respond(id_,result=None,error=None):
    msg={'jsonrpc':'2.0','id':id_}
    if error is not None: msg['error']=error
    else: msg['result']=result
    sys.stdout.write(json.dumps(msg,ensure_ascii=False,separators=(',',':'))+'\n')
    sys.stdout.flush()

def process(message):
    if not isinstance(message,dict): return
    method=message.get('method'); id_=message.get('id')
    if method is None: return
    if id_ is None: return  # notifications have no responses
    params=message.get('params') or {}
    if method=='initialize':
        requested=params.get('protocolVersion','2025-06-18')
        version=requested if requested in ('2024-11-05','2025-03-26','2025-06-18','2025-11-25') else '2025-06-18'
        return respond(id_,{'protocolVersion':version,'capabilities':{'tools':{'listChanged':False}},'serverInfo':{'name':'offline-ontology','version':'1.1.0'}})
    if method=='ping': return respond(id_,{})
    if method=='tools/list':
        return respond(id_,{'tools':[{'name':name,'description':v[0], 'inputSchema':{'type':'object','properties':v[2],'required':v[3],'additionalProperties':False}} for name,v in TOOLS.items()]})
    if method=='tools/call':
        name=params.get('name'); arguments=params.get('arguments') or {}
        if name not in TOOLS: return respond(id_,error={'code':-32602,'message':'Unknown tool'})
        try:
            if not isinstance(arguments,dict): fail('arguments must be object')
            for key in TOOLS[name][3]:
                if key not in arguments: fail(f'missing argument {key}')
            data=TOOLS[name][1](arguments)
            return respond(id_,{'content':[{'type':'text','text':json.dumps(data,ensure_ascii=False)}], 'isError':False})
        except (ValueError,TypeError,sqlite3.Error) as exc:
            return respond(id_,{'content':[{'type':'text','text':str(exc)}],'isError':True})
    return respond(id_,error={'code':-32601,'message':'Method not found'})

def main():
    with dbconn(): pass
    print(f'ontology MCP ready ({DB})',file=sys.stderr,flush=True)
    for raw in sys.stdin.buffer:
        if len(raw)>MAX_BYTES:
            print('oversized MCP message ignored',file=sys.stderr); continue
        try: process(json.loads(raw))
        except (ValueError,TypeError,KeyError) as exc:
            print('invalid message:',exc,file=sys.stderr)

if __name__=='__main__': main()
