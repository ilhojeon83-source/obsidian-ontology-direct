import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
class MCPTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        env=os.environ.copy(); env['ONTOLOGY_DB']=str(Path(self.tmp.name)/'ontology.db')
        self.proc=subprocess.Popen([sys.executable,str(ROOT/'server.py')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
        self.callid=0
        self.request('initialize',{'protocolVersion':'2025-06-18','capabilities':{},'clientInfo':{'name':'test','version':'1'}})
    def tearDown(self):
        self.proc.stdin.close(); self.proc.wait(timeout=5); self.proc.stdout.close(); self.proc.stderr.close(); self.tmp.cleanup()
    def request(self,method,params=None):
        self.callid+=1
        self.proc.stdin.write((json.dumps({'jsonrpc':'2.0','id':self.callid,'method':method,'params':params or {}},ensure_ascii=False)+'\n').encode())
        self.proc.stdin.flush()
        raw=self.proc.stdout.readline()
        self.assertTrue(raw,'server closed unexpectedly')
        result=json.loads(raw)
        self.assertEqual(result['id'],self.callid)
        self.assertNotIn('error',result)
        return result['result']
    def tool(self,name,arguments=None):
        r=self.request('tools/call',{'name':name,'arguments':arguments or {}})
        self.assertFalse(r.get('isError'),r)
        return json.loads(r['content'][0]['text'])
    def test_tools(self):
        names=[x['name'] for x in self.request('tools/list')['tools']]
        self.assertIn('ontology_ingest_document',names)
        self.assertIn('ontology_query_graph',names)
    def test_ingest_update_and_shared_evidence(self):
        e=[{'id':'system:s','name':'System S','type':'System'}, {'id':'technology:os','name':'OS','type':'Technology'}, {'id':'technology:new','name':'New OS','type':'Technology'}]
        rel={'subject':'system:s','predicate':'RUNS_ON','object':'technology:os','evidence':'S runs on OS','assertion':'explicit'}
        doc=lambda path,h,rels:{'path':path,'sha256':h*64,'entities':e,'relations':rels}
        r=self.tool('ontology_ingest_document',doc('Projects/a.md','a',[rel]))
        self.assertEqual(r['status'],'indexed')
        self.assertEqual(self.tool('ontology_ingest_document',doc('Projects/a.md','a',[rel]))['status'],'unchanged')
        self.tool('ontology_ingest_document',doc('Projects/b.md','b',[rel]))
        self.assertEqual(self.tool('ontology_stats')['evidence'],2)
        self.tool('ontology_ingest_document',doc('Projects/a.md','c',[]))
        self.assertEqual(self.tool('ontology_stats')['relations'],1)
        self.tool('ontology_delete_document',{'path':'Projects/b.md'})
        self.assertEqual(self.tool('ontology_stats')['relations'],0)
        self.assertEqual(self.tool('ontology_stats')['entities'],3)
        new_rel=dict(rel,object='technology:new',evidence='S uses New OS')
        self.tool('ontology_ingest_document',doc('Projects/a.md','d',[new_rel]))
        g=self.tool('ontology_query_graph',{'entity_id':'system:s','depth':1})
        self.assertEqual(len(g['relations']),1)
        self.assertEqual(g['relations'][0]['object_id'],'technology:new')
        self.assertEqual(g['relations'][0]['evidence'][0]['source_path'],'Projects/a.md')
    def test_invalid_reference_keeps_old_data(self):
        ents=[{'id':'issue:x','name':'X','type':'Issue'}, {'id':'technology:y','name':'Y','type':'Technology'}]
        doc={'path':'Incidents/x.md','sha256':'1'*64,'entities':ents,'relations':[{'subject':'issue:x','predicate':'AFFECTS','object':'technology:y','evidence':'X affects Y'}]}
        self.tool('ontology_ingest_document',doc)
        doc['sha256']='2'*64
        doc['relations'][0]['object']='missing'
        result=self.request('tools/call',{'name':'ontology_ingest_document','arguments':doc})
        self.assertTrue(result['isError'])
        self.assertEqual(self.tool('ontology_stats')['evidence'],1)
        self.assertEqual(self.tool('ontology_get_document_state',{'paths':['Incidents/x.md']})['documents'][0]['sha256'],'1'*64)
    def test_path_traversal_rejected(self):
        r=self.request('tools/call',{'name':'ontology_delete_document','arguments':{'path':'../secret.md'}})
        self.assertTrue(r['isError'])
if __name__=='__main__': unittest.main()
