import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class SearchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory()
        env=os.environ.copy(); env['ONTOLOGY_DB']=str(Path(cls.temp.name)/'graph.sqlite')
        cls.proc=subprocess.Popen([sys.executable,str(ROOT/'server.py')],env=env,
            stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        cls.seq=0
        cls.raw('initialize', {'protocolVersion':'2025-06-18'})
        entities=[
            dict(id='system:tcp-server',name='TCP Server',type='System',aliases=['TCP 서비스','통신 서버']),
            dict(id='os:rocky:10',name='Rocky Linux 10',type='Technology',aliases=['록키 리눅스 10','Rocky10']),
            dict(id='issue:ipv4',name='IPv4 연결 실패',type='Issue',aliases=['IPv4 장애','아이피 연결오류']),
            dict(id='task:dualstack',name='IPv6 dual-stack 활성화',type='Task',aliases=['듀얼스택 설정']),
            dict(id='project:migration',name='운영체제 마이그레이션',type='Project',aliases=['OS 이전']),
            dict(id='person:kim',name='김철수',type='Person',aliases=['김 연구원']),
            dict(id='decision:tls',name='TLS 1.2 정책 도입',type='Decision',aliases=['암호화 정책']),
            dict(id='technology:python314',name='Python 3.14',type='Technology',aliases=['파이썬 3.14']),
        ]
        data=[
           ('Incidents/IPv4_연결실패.md','issue:ipv4','AFFECTS','system:tcp-server','IPv6 전용 리스너 때문에 IPv4 접속에 실패했다.'),
           ('Incidents/IPv4_연결실패.md','issue:ipv4','RESOLVED_BY','task:dualstack','dual-stack 설정으로 장애를 해결했다.'),
           ('Projects/Rocky10_전환.md','project:migration','USES','os:rocky:10','Rocky Linux 10으로 시스템을 이전한다.'),
           ('Projects/Rocky10_전환.md','system:tcp-server','RUNS_ON','os:rocky:10','서버의 운영체제는 Rocky Linux 10이다.'),
           ('Meetings/정책_회의.md','decision:tls','RELATED_TO','system:tcp-server','보안 회의에서 TLS 1.2 이상을 유지하기로 결정했다.'),
           ('Projects/Rocky10_전환.md','system:tcp-server','USES','technology:python314','Python 3.14를 이용하여 서버를 구현한다.'),
           ('Meetings/담당자.md','person:kim','ASSIGNED_TO','project:migration','김철수는 마이그레이션 담당자다.'),
        ]
        for path in sorted(set(x[0] for x in data)):
            rels=[dict(subject=s,predicate=p,object=o,evidence=q) for f,s,p,o,q in data if f==path]
            cls.tool('ontology_ingest_document',{'path':path,'sha256':hashlib.sha256(path.encode()).hexdigest(),
                                                  'entities':entities,'relations':rels})
    @classmethod
    def tearDownClass(cls):
        cls.proc.stdin.close(); cls.proc.wait(timeout=5); cls.proc.stdout.close(); cls.proc.stderr.close(); cls.temp.cleanup()
    @classmethod
    def raw(cls,method,params):
        cls.seq+=1
        cls.proc.stdin.write((json.dumps(dict(jsonrpc='2.0',id=cls.seq,method=method,params=params),ensure_ascii=False)+'\n').encode())
        cls.proc.stdin.flush()
        out=json.loads(cls.proc.stdout.readline())
        return out['result']
    @classmethod
    def tool(cls,name,args):
        result=cls.raw('tools/call',dict(name=name,arguments=args))
        if result.get('isError'): raise AssertionError(result['content'])
        return json.loads(result['content'][0]['text'])
    def s(self,q,mode='auto'):
        return self.tool('ontology_search',dict(query=q,mode=mode))
    def e(self,q,mode='auto'):
        return self.tool('ontology_search_entities',dict(query=q,mode=mode))
    def test_01_exact_entity(self): self.assertEqual(self.e('TCP Server')['entities'][0]['id'],'system:tcp-server')
    def test_02_alias(self): self.assertEqual(self.e('통신 서버')['entities'][0]['id'],'system:tcp-server')
    def test_03_korean_no_space(self): self.assertEqual(self.e('IPv4연결실패')['entities'][0]['id'],'issue:ipv4')
    def test_04_korean_spaced(self): self.assertEqual(self.e('IPv4 연결 실패')['entities'][0]['id'],'issue:ipv4')
    def test_05_unicode_nfkc(self): self.assertEqual(self.e('Ｐｙｔｈｏｎ ３．１４')['entities'][0]['id'],'technology:python314')
    def test_06_mixed_terms(self): self.assertTrue(self.s('Rocky Linux 10 TCP 서버')['matches'])
    def test_07_cross_fields(self): self.assertTrue(self.s('IPv4 AFFECTS TCP')['matches'])
    def test_08_path_match(self): self.assertTrue(self.s('정책 회의')['matches'])
    def test_09_predicate(self): self.assertTrue(self.s('RESOLVED_BY')['matches'])
    def test_10_korean_partial(self): self.assertTrue(self.s('듀얼스택 설정')['matches'])
    def test_11_fallback(self):
        x=self.s('존재하지않는단어 IPv4 TCP')
        self.assertTrue(x['fallback_to_any']); self.assertTrue(x['matches'])
    def test_12_all_strict(self): self.assertEqual(self.s('없는용어 IPv4',mode='all')['matches'],[])
    def test_13_any_loose(self): self.assertTrue(self.s('없는용어 IPv4',mode='any')['matches'])
    def test_14_phrase(self): self.assertTrue(self.s('TLS 1.2',mode='phrase')['matches'])
    def test_15_no_results(self): self.assertEqual(self.s('zzzzunfindablexx')['matches'],[])
    def test_16_stopwords(self): self.assertTrue(self.s('TCP 서버 관련 문서 찾아줘')['matches'])
    def test_17_alias_entity_search(self): self.assertEqual(self.e('록키 리눅스')['entities'][0]['id'],'os:rocky:10')
    def test_18_hyphen(self): self.assertTrue(self.s('dual stack')['matches'])
    def test_19_limit(self): self.assertLessEqual(len(self.s('TCP')['matches']),20)
    def test_20_version_number(self): self.assertTrue(self.s('Python 3.14')['matches'])
    def test_21_id_search(self): self.assertEqual(self.e('person:kim')['entities'][0]['id'],'person:kim')
    def test_22_related_issues(self): self.assertTrue(self.s('IPv4 장애')['matches'])
    def test_23_casefold(self): self.assertEqual(self.e('tcp server')['entities'][0]['id'],'system:tcp-server')
    def test_24_unknown_entity(self): self.assertEqual(self.e('zzzznotfound')['entities'],[])
    def test_25_metadata(self):
        r=self.s('IPv4 TCP'); self.assertIn('matched_terms',r['matches'][0]);self.assertIn('score',r['matches'][0])
    def test_26_injection_is_plain_text(self): self.assertLess(len(self.e("' OR 1=1 --",mode="all")['entities']),8)
    def test_27_entity_query_relaxed(self): self.assertTrue(self.e('TCP 아무말')['fallback_to_any'])
    def test_28_alias_cross_field(self): self.assertTrue(self.s('통신 서버 Rocky10')['matches'])
    def test_29_korean_and_eng(self): self.assertTrue(self.s('마이그레이션 Rocky')['matches'])
    def test_30_source_filename(self): self.assertTrue(self.s('IPv4 연결실패')['matches'])

if __name__=='__main__': unittest.main()
