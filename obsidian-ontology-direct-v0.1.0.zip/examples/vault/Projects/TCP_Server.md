---
id: system:tcp-server
type: System
aliases:
  - TCP 서비스
---
# TCP Server

TCP Server는 Rocky Linux 10에서 실행된다.
TCP Server는 Python 3.14를 사용한다.
TCP Server는 Nginx를 프록시로 사용한다.

관련 이슈: [[../Incidents/IPv4_연결실패]]
