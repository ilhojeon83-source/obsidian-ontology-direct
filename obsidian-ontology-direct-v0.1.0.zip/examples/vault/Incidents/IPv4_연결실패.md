---
id: issue:ipv4-connectivity
status: resolved
---
# IPv4 연결 실패

TCP Server에서 IPv4 연결 실패 장애가 발생했다.
장애 원인은 IPv6 전용 소켓 설정이었다.
네트워크 설정 작업으로 dual-stack을 활성화하여 장애를 해결했다.

관련 시스템: [[../Projects/TCP_Server]]
